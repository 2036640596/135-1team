create view V_RENEW_DEVICE as
  select rd.uuid,
       rd.brand_id,
       rb.brand_name,
       rd.device_model,
       rd.default_param_items,
       (select wm_concat(id) from T_UPLOAD_FILES where PARENT_ID = rd.UUID) as picture_id,
       rd.min_price,
       rd.max_price,
       --rd.photos,
       --rd.customer_service,
       rd.official_price,
       rd.view_order,
       rd.created_by,
       rd.creation_date,
       rd.last_update_by,
       rd.last_update_date,
       rd.ext_field1,
       rd.ext_field2,
       rd.memo
  from t_renew_device rd,
        t_recovery_brand rb
where rb.brand_type = 'NEW_PHONE' and rb.uuid = rd.brand_id
/

