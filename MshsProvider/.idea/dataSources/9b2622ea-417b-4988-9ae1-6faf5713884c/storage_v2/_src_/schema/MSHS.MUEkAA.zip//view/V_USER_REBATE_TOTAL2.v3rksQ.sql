create view V_USER_REBATE_TOTAL2 as
  select
  ua.user_id,
  nvl(ua.REAL_name, ua.login_name) as user_name,
  ua.parent_id,
  ua.real_name,
  first_finally_amount, first_rebate,
  second_finally_amount, second_rebate,
  third_finally_amount, third_rebate,
  (nvl(first_rebate, 0) + nvl(second_rebate, 0) + nvl(third_rebate, 0)) as total_rebate
from v_user_account ua
join
(select r.first_user, sum(r.FINALLY_AMOUNT) as first_finally_amount, sum(first_rebate) as first_rebate
from t_order_rebate r
where substr(r.creation_date, 1, 10) >= rebate_view_param.get_start_date and substr(r.creation_date, 1, 10) <= rebate_view_param.get_end_date()
group by r.first_user) f on ua.user_id = f.first_user
join
(select r.second_user, sum(r.FINALLY_AMOUNT) as second_finally_amount, sum(second_rebate) as second_rebate
from t_order_rebate r
where substr(r.creation_date, 1, 10) >= rebate_view_param.get_start_date and substr(r.creation_date, 1, 10) <= rebate_view_param.get_end_date()
group by r.second_user) s on ua.user_id = s.second_user
join
(select r.third_user, sum(r.FINALLY_AMOUNT) as third_finally_amount, sum(third_rebate) as third_rebate
from t_order_rebate r
where substr(r.creation_date, 1, 10) >= rebate_view_param.get_start_date and substr(r.creation_date, 1, 10) <= rebate_view_param.get_end_date()
group by r.third_user) t on t.third_user = ua.user_id
/

