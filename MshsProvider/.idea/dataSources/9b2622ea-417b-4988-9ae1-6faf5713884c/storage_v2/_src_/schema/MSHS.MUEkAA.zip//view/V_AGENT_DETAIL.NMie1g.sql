create view V_AGENT_DETAIL as
  select m.order_no,
       m.store_user as user_id,
       ua.telphone as telphone,
       REAL_NAME,
       u.parent_id,
       CHECK_BRAND_ID as brand_id,
       CHECK_BRAND_NAME as brand_name,
       CHECK_DEVICE_ID as device_id,
       CHECK_DEVICE_MODEL as device_model,
       DEVICE_PICTURE_ID,
       SERIAL_NUMBER,
       FINALLY_AMOUNT,
       CHECK_DATE,
       TRADE_TYPE,
       DISCOUNT_AMOUNT,
       STORE_ID,
       s.name as store_name,
       ORDER_STATUS,
       total_rebate, first_rebate, first_user, second_rebate, second_user, third_rebate, third_user
  from t_order_detail d,
       t_order_main   m,
       t_users        u,
       t_store        s,
       t_user_account ua, t_order_rebate r
 where d.order_id = m.order_no
   and m.store_user = u.id
   and u.user_type = 2
   and m.store_id = s.uuid(+)
   and ua.user_id = u.id
   and m.order_status = 5
   and m.order_no = r.order_no
/

