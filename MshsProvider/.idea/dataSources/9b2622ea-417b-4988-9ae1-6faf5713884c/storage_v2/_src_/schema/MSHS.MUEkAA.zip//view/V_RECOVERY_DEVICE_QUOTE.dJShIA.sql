create view V_RECOVERY_DEVICE_QUOTE as
  select dq.uuid,
       rd.brand_id,
       rd.brand_name,
       rd.device_model,
       rd.min_price,
       rd.max_price,
       rd.os,
       rci.category_id,
       rci.category_name,
       rci.item_name,
       dq.device_id,
       dq.item_code,
       dq.quote,
       dq.created_by,
       dq.creation_date,
       dq.last_update_by,
       dq.last_update_date,
       dq.ext_field1,
       dq.ext_field2,
       dq.memo
  from T_recovery_DEVICE_QUOTE  dq,
       v_recovery_device        rd,
       v_recovery_check_item    rci
 where dq.device_id = rd.uuid
   and dq.item_code = rci.item_code
   and rd.os = rci.os
order by rd.brand_view_order, rd.view_order, rci.category_view_order, rci.view_order
/

