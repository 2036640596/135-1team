create view V_RECOVERY_DEVICE as
  select rd.uuid,
       rd.brand_id,
       rb.brand_code,
       rb.brand_name,
       decode(rb.brand_name, '苹果', 'iOS', 'Android') as os,
       rb.brand_type,
       rb.brand_picture_id,
       rb.view_order as brand_view_order,
       rd.device_model,
       rd.device_picture_id,
       rd.min_price,
       rd.max_price,
       rd.view_order,
       rd.created_by,
       rd.creation_date,
       rd.last_update_by,
       rd.last_update_date,
       rd.ext_field1,
       rd.ext_field2,
       rd.memo
  from t_recovery_device rd, t_recovery_brand rb
where rd.brand_id = rb.uuid
/

