create view V_RECOVERY_CHECK_ITEM as
  select rci.category_id,
       rcc.category_name,
       rcc.category_type,
       rcc.view_order as category_view_order,
       rcc.os,
       rci.uuid,
       rci.item_NAME,
       rci.item_code,
       rci.picture_id,
       rci.view_order,
       rci.ext_field1,
       rci.ext_field2,
       rci.created_by,
       rci.creation_date,
       rci.last_update_by,
       rci.last_update_date,
       rci.memo
  from t_recovery_check_category rcc, t_recovery_check_item rci
 where rcc.uuid = rci.category_id
 order by rcc.view_order, rci.view_order
/

